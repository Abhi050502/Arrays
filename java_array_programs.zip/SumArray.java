public class SumArray {
    public static void main(String[] args) {
        int[] arr = {5, 10, 15, 20};
        int sum = 0;
        for (int i : arr) {
            sum += i;
        }
        System.out.println("Sum = " + sum);
    }
}