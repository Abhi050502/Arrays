public class ArrayDeclare {
    public static void main(String[] args) {
        int[] arr = {10, 20, 30, 40, 50};
        for (int i : arr) {
            System.out.print(i + " ");
        }
    }
}